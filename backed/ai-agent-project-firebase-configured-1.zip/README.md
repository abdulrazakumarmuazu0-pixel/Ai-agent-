# 🤖 AI Agent - Full Stack Application

A production-ready AI Agent with chat, web search, file processing, memory, and multi-language support. The backend verifies Firebase ID tokens, stores application data in Firestore, and exposes health/readiness endpoints for deployment platforms.

## Improvements in this release

- Safer startup and graceful shutdown with configurable CORS, request IDs, body limits, and health/readiness endpoints.
- Fixed the frontend chat JavaScript syntax error that prevented the UI from loading.
- Added deployment-aware API URL configuration and graceful Firebase placeholder handling.
- Added browser-side file type validation, safer rendering, duplicate-listener protection, and voice/notification guards.
- Corrected Firestore rules to use the `memories` collection and protect ownership fields.
- Added automated API smoke tests and a production environment template.

## 🚀 Features

- **AI Chat** - Conversational AI with streaming responses
- **Web Search** - Real-time web search with Google CSE
- **File Processing** - Upload and extract text from PDF, DOCX, Excel, images
- **Memory System** - Persistent user memory and preferences
- **Multi-Language** - English, Hausa, and Arabic (RTL support)
- **Voice Input** - Speech-to-text using Web Speech API
- **PWA** - Installable Progressive Web App
- **Admin Dashboard** - User management and system stats
- **Security** - JWT auth, rate limiting, encryption

## 📁 Project Structure

```
ai-agent-project/
├── backend/          # Node.js/Express API
│   ├── config/       # Database & Firebase config
│   ├── middleware/   # Auth, rate limit, error handler
│   ├── models/       # Data models (User, Message, etc.)
│   ├── routes/       # API endpoints
│   ├── services/     # Business logic (AI, Search, Files)
│   └── utils/        # Helpers, validators, encryption
├── frontend/         # PWA (HTML/CSS/JS)
│   ├── css/          # Styles
│   ├── js/           # App logic
│   └── assets/       # Icons, images
└── docs/             # Documentation
```

## 🛠️ Setup

### Prerequisites
- Node.js 18+
- Firebase project
- OpenAI API key
- Google API key + Custom Search Engine ID

### Backend Setup

```bash
cd backend
npm install

# Create .env file (see .env.example)
cp .env.example .env

# Validate the public API
npm test -- --runInBand

# Start server
npm run dev
```

### Frontend Setup

Serve the `frontend` folder with any static server:
```bash
# Option 1: Python
cd frontend && python -m http.server 8080

# Option 2: Node.js
npx serve frontend
```

### Firebase Setup

1. Create a Firebase project and enable Authentication and Firestore.
2. Register a Web App and copy its configuration into `frontend/js/firebase-config.js`, or inject `window.FIREBASE_CONFIG` at deploy time.
3. Generate a service account and add its values to `backend/.env`; never commit the file.
4. Deploy the rules with `firebase deploy --only firestore:rules`.
5. Set `CORS_ORIGINS` to the exact deployed frontend origin.

## 🔌 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/health` | Liveness check |
| GET | `/api/ready` | Readiness check |
| POST | `/api/auth/register` | Sync a newly authenticated Firebase user |
| POST | `/api/auth/login` | Sync an existing Firebase user |
| GET | `/api/auth/me` | Get current user |
| POST | `/api/chat/message` | Send message |
| GET | `/api/chat/conversations` | List conversations |
| POST | `/api/files/upload` | Upload file |
| POST | `/api/search/web` | Web search |
| GET | `/api/memory` | Get memories |
| GET | `/api/admin/stats` | Admin stats |

## 🔐 Environment Variables

Copy `backend/.env.example` to `backend/.env`. The most important production values are:

```env
NODE_ENV=production
PORT=5000
CORS_ORIGINS=https://your-frontend-domain.com
FIREBASE_PROJECT_ID=your-project
FIREBASE_PRIVATE_KEY="-----BEGIN PRIVATE KEY-----\n..."
FIREBASE_CLIENT_EMAIL=...
OPENAI_API_KEY=sk-...
```

## 📱 PWA Installation

1. Open the app in Chrome/Edge
2. Click "Install" in the address bar
3. The app will be added to your home screen

## 🌍 Languages

- **English** (`en`) - Default
- **Hausa** (`ha`) - RTL disabled
- **Arabic** (`ar`) - RTL enabled

## ✅ Validation

Run `npm test -- --runInBand` inside `backend` to execute the public API smoke suite. All JavaScript source files can be syntax-checked with `find backend frontend -path '*/node_modules' -prune -o -name '*.js' -type f -print0 | xargs -0 -n1 node --check`.

## 📝 License

MIT License
