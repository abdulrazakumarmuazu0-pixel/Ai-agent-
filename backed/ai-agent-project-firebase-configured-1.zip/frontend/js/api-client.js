const API_BASE_URL = (window.APP_CONFIG?.apiBaseUrl || document.querySelector('meta[name="api-base-url"]')?.content || (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1' ? 'http://localhost:5000/api' : '/api')).replace(/\/$/, '');

class ApiClient {
  constructor() { this.baseURL = API_BASE_URL; this.token = localStorage.getItem('token'); }
  setToken(token) { this.token = token; if (token) localStorage.setItem('token', token); else localStorage.removeItem('token'); }
  getToken() { return this.token || localStorage.getItem('token'); }
  async getFreshToken() { if (window.firebase?.auth?.().currentUser) { try { const token = await firebase.auth().currentUser.getIdToken(); this.setToken(token); return token; } catch (_) {} } return this.getToken(); }
  async getHeaders(includeJson = true) { const headers = includeJson ? { 'Content-Type': 'application/json' } : {}; const token = await this.getFreshToken(); if (token) headers.Authorization = `Bearer ${token}`; return headers; }
  async request(endpoint, options = {}) {
    const response = await fetch(`${this.baseURL}${endpoint}`, { ...options, headers: { ...(await this.getHeaders(options.body !== undefined ? options.body instanceof FormData === false : true)), ...options.headers } });
    let data = null; try { data = await response.json(); } catch (_) { data = { success: false, message: 'The server returned an invalid response.' }; }
    if (!response.ok) { if (response.status === 401) { this.setToken(null); window.dispatchEvent(new CustomEvent('auth:expired')); } const error = new Error(data.message || `Request failed: ${response.status}`); error.code = data.code; error.status = response.status; throw error; }
    return data;
  }
  register(data = {}) { return this.request('/auth/register', { method: 'POST', body: JSON.stringify(data) }); }
  login() { return this.request('/auth/login', { method: 'POST' }); }
  getMe() { return this.request('/auth/me'); }
  updateProfile(data) { return this.request('/auth/profile', { method: 'PUT', body: JSON.stringify(data) }); }
  logout() { this.setToken(null); return Promise.resolve({ success: true }); }
  sendMessage(message, conversationId, language) { return this.request('/chat/message', { method: 'POST', body: JSON.stringify({ message, conversationId, language }) }); }
  getConversations(limit = 20) { return this.request(`/chat/conversations?limit=${encodeURIComponent(limit)}`); }
  getMessages(id) { return this.request(`/chat/conversations/${encodeURIComponent(id)}/messages`); }
  deleteConversation(id) { return this.request(`/chat/conversations/${encodeURIComponent(id)}`, { method: 'DELETE' }); }
  async uploadFile(file, conversationId, description) { const form = new FormData(); form.append('file', file); if (conversationId) form.append('conversationId', conversationId); if (description) form.append('description', description); return this.request('/files/upload', { method: 'POST', body: form }); }
  getFiles(limit = 20) { return this.request(`/files?limit=${encodeURIComponent(limit)}`); }
  deleteFile(id) { return this.request(`/files/${encodeURIComponent(id)}`, { method: 'DELETE' }); }
  webSearch(query, numResults = 10, language) { return this.request('/search/web', { method: 'POST', body: JSON.stringify({ query, numResults, language }) }); }
  saveMemory(key, value, type, importance) { return this.request('/memory', { method: 'POST', body: JSON.stringify({ key, value, type, importance }) }); }
  getMemories() { return this.request('/memory'); }
  deleteMemory(key) { return this.request(`/memory/${encodeURIComponent(key)}`, { method: 'DELETE' }); }
}
const api = new ApiClient();
