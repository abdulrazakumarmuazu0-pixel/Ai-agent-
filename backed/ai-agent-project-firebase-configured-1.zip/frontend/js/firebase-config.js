/* Copy this file's values from Firebase Console -> Project settings -> Web app. */
const firebaseConfig = window.FIREBASE_CONFIG || {
  apiKey: 'AIzaSyDN7yL9vISJUoLLOh0gXFck-y9wwWphP6U',
  authDomain: 'ai-agent-5a70d.firebaseapp.com',
  projectId: 'ai-agent-5a70d',
  storageBucket: 'ai-agent-5a70d.firebasestorage.app',
  messagingSenderId: '76004420497',
  appId: '1:76004420497:web:072893ba3caadc3dc34830',
  measurementId: 'G-R5YN3S37H8'
};

const firebaseConfigured = Object.values(firebaseConfig).every(value => value && !String(value).includes('REPLACE_WITH_YOUR'));
if (firebaseConfigured) {
  firebase.initializeApp(firebaseConfig);
  firebase.auth().setPersistence(firebase.auth.Auth.Persistence.LOCAL).catch(console.warn);
  var googleProvider = new firebase.auth.GoogleAuthProvider();
} else {
  window.firebaseConfigurationError = 'Firebase is not configured. Add FIREBASE_CONFIG before using authentication.';
  window.googleProvider = null;
  document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('#login-form button, #register-form button, #google-signin-btn').forEach(button => { button.disabled = true; });
    const error = document.getElementById('login-error');
    if (error) error.textContent = 'Application configuration is incomplete. Contact the administrator.';
  });
}
