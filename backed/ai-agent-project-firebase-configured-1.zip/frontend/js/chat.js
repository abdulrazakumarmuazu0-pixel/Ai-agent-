class ChatManager {
  constructor() { this.currentConversationId = null; this.messages = []; this.isLoading = false; }

  async init() { await this.loadConversations(); if (!this.listenersReady) { this.setupEventListeners(); this.listenersReady = true; } }
  setupEventListeners() {
    const input = document.getElementById('message-input');
    const send = document.getElementById('send-btn');
    document.getElementById('new-chat-btn')?.addEventListener('click', () => this.startNewChat());
    input?.addEventListener('input', () => { send.disabled = !input.value.trim() || this.isLoading; this.autoResizeTextarea(input); });
    input?.addEventListener('keydown', event => {
      if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); this.sendMessage(); }
    });
    send?.addEventListener('click', () => this.sendMessage());
    document.querySelectorAll('.quick-action').forEach(button => button.addEventListener('click', () => {
      input.value = button.dataset.prompt || ''; input.dispatchEvent(new Event('input')); input.focus();
    }));
  }
  autoResizeTextarea(textarea) { textarea.style.height = 'auto'; textarea.style.height = `${Math.min(textarea.scrollHeight, 200)}px`; }
  async loadConversations() {
    try { const response = await api.getConversations(); if (response.success) this.renderConversations(response.data.conversations || []); }
    catch (error) { console.error('Failed to load conversations:', error); showToast(error.message, 'error'); }
  }
  renderConversations(conversations) {
    const list = document.getElementById('conversations-list'); if (!list) return;
    if (!conversations.length) { list.innerHTML = `<div class="no-conversations">${i18n.t('noConversations')}</div>`; return; }
    list.innerHTML = conversations.map(conv => `<button class="conversation-item ${conv.id === this.currentConversationId ? 'active' : ''}" data-id="${this.escapeHtml(conv.id)}" type="button"><span class="conv-icon">💬</span><span class="conv-title">${this.escapeHtml(conv.title || 'Untitled conversation')}</span><span class="conv-time">${this.escapeHtml(this.formatTime(conv.updatedAt))}</span></button>`).join('');
    list.querySelectorAll('.conversation-item').forEach(item => item.addEventListener('click', () => this.loadConversation(item.dataset.id)));
  }
  async loadConversation(id) {
    try { const response = await api.getMessages(id); if (!response.success) throw new Error(response.message); this.currentConversationId = id; this.messages = response.data.messages || []; document.getElementById('chat-title').textContent = response.data.conversation.title; this.renderMessages(); this.highlightConversation(id); }
    catch (error) { showToast(error.message, 'error'); }
  }
  highlightConversation(id) { document.querySelectorAll('.conversation-item').forEach(item => item.classList.toggle('active', item.dataset.id === id)); }
  startNewChat() { this.currentConversationId = null; this.messages = []; document.getElementById('chat-title').textContent = i18n.t('newChat'); this.renderMessages(); this.highlightConversation(null); document.getElementById('message-input')?.focus(); }
  async sendMessage() {
    const input = document.getElementById('message-input'); const send = document.getElementById('send-btn'); const message = input?.value.trim();
    if (!message || this.isLoading) return;
    this.isLoading = true; this.addMessageToUI('user', message); input.value = ''; input.style.height = 'auto'; send.disabled = true; this.showTypingIndicator();
    try { const response = await api.sendMessage(message, this.currentConversationId, i18n.getCurrentLanguage()); if (!response.success) throw new Error(response.message); this.currentConversationId = response.data.conversationId; this.addMessageToUI('assistant', response.data.message.content); await this.loadConversations(); }
    catch (error) { this.addMessageToUI('assistant', `${i18n.t('error')}: ${error.message}`, true); showToast(error.message, 'error'); }
    finally { this.isLoading = false; this.hideTypingIndicator(); send.disabled = !input.value.trim(); }
  }
  addMessageToUI(role, content, isError = false) {
    const container = document.getElementById('messages-container'); document.getElementById('welcome-message')?.remove();
    const node = document.createElement('div'); node.className = `message ${role}`; node.innerHTML = `<div class="message-avatar">${role === 'user' ? '👤' : '🤖'}</div><div><div class="message-content ${isError ? 'error' : ''}">${this.formatMessage(content)}</div><div class="message-time">${this.escapeHtml(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }))}</div></div>`; container.appendChild(node); this.scrollToBottom();
  }
  formatMessage(content = '') {
    let value = this.escapeHtml(String(content));
    value = value.replace(/```([\w-]*)\n?([\s\S]*?)```/g, '<pre><code>$2</code></pre>');
    value = value.replace(/`([^`]+)`/g, '<code>$1</code>').replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>').replace(/\*([^*]+)\*/g, '<em>$1</em>');
    value = value.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
    return value.replace(/\n/g, '<br>');
  }
  escapeHtml(value) { const div = document.createElement('div'); div.textContent = value; return div.innerHTML; }
  showTypingIndicator() { const container = document.getElementById('messages-container'); if (document.getElementById('typing-indicator')) return; const node = document.createElement('div'); node.id = 'typing-indicator'; node.className = 'message assistant'; node.innerHTML = '<div class="message-avatar">🤖</div><div class="message-content"><div class="typing-indicator"><span></span><span></span><span></span></div></div>'; container.appendChild(node); this.scrollToBottom(); }
  hideTypingIndicator() { document.getElementById('typing-indicator')?.remove(); }
  scrollToBottom() { const container = document.getElementById('messages-container'); if (container) container.scrollTop = container.scrollHeight; }
  renderMessages() {
    const container = document.getElementById('messages-container'); container.innerHTML = '';
    if (!this.messages.length) { const welcome = document.getElementById('welcome-message') || document.createElement('div'); welcome.id = 'welcome-message'; welcome.className = 'welcome-message'; welcome.innerHTML = '<div class="welcome-icon">🤖</div><h2>How can I help you today?</h2><p>Ask me anything, search the web, or upload files.</p>'; container.appendChild(welcome); return; }
    this.messages.forEach(msg => this.addMessageToUI(msg.role, msg.content)); this.scrollToBottom();
  }
  formatTime(timestamp) { if (!timestamp) return ''; const date = new Date(timestamp); if (Number.isNaN(date.getTime())) return ''; const diff = Date.now() - date.getTime(); if (diff < 60000) return 'Just now'; if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`; if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`; return date.toLocaleDateString(); }
}
const chat = new ChatManager();
