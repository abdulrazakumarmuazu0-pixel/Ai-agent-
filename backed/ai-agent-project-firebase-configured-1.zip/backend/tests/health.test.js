const request = require('supertest');
const { app } = require('../server');

describe('public API', () => {
  test('GET /api/health returns service metadata', async () => {
    const response = await request(app).get('/api/health');
    expect(response.statusCode).toBe(200);
    expect(response.body.success).toBe(true);
    expect(response.body.status).toBe('healthy');
    expect(response.headers['x-request-id']).toBeDefined();
  });

  test('GET /api/ready returns readiness status', async () => {
    const response = await request(app).get('/api/ready');
    expect(response.statusCode).toBe(200);
    expect(response.body.status).toBe('ready');
  });

  test('unknown routes return a stable JSON error', async () => {
    const response = await request(app).get('/api/does-not-exist');
    expect(response.statusCode).toBe(404);
    expect(response.body.code).toBe('NOT_FOUND');
    expect(response.body.requestId).toBeDefined();
  });
});
