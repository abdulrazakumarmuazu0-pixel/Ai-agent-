const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const dotenv = require('dotenv');
const path = require('path');
const crypto = require('crypto');

dotenv.config();

const { connectDatabase } = require('./config/database');
const { initializeFirebase } = require('./config/firebase');
const errorHandler = require('./middleware/error-handler');
const authRoutes = require('./routes/auth');
const chatRoutes = require('./routes/chat');
const fileRoutes = require('./routes/files');
const searchRoutes = require('./routes/search');
const memoryRoutes = require('./routes/memory');
const adminRoutes = require('./routes/admin');
const logger = require('./utils/logger');
const { startCleanupJob } = require('./jobs/cleanup');

const app = express();
const PORT = Number(process.env.PORT) || 5000;
const isProduction = process.env.NODE_ENV === 'production';

const configuredOrigins = (process.env.CORS_ORIGINS || '')
  .split(',').map(origin => origin.trim()).filter(Boolean);
const allowedOrigins = configuredOrigins.length ? configuredOrigins : [
  'http://localhost:3000', 'http://localhost:5000', 'http://localhost:8080',
  'http://127.0.0.1:5500', 'http://127.0.0.1:8080'
];

app.disable('x-powered-by');
app.set('trust proxy', 1);
app.use(helmet({
  contentSecurityPolicy: isProduction ? {
    directives: {
      defaultSrc: ["'self'"], connectSrc: ["'self'", 'https:', 'wss:'],
      scriptSrc: ["'self'", 'https://www.gstatic.com'],
      styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
      imgSrc: ["'self'", 'data:', 'https:'], fontSrc: ["'self'", 'https:', 'data:']
    }
  } : false,
  crossOriginEmbedderPolicy: false
}));
app.use(cors({
  origin: (origin, callback) => {
    if (!origin || allowedOrigins.includes('*') || allowedOrigins.includes(origin)) return callback(null, true);
    return callback(new Error('Origin is not allowed by CORS'));
  }, credentials: true, methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With', 'X-Request-ID']
}));

const limiter = rateLimit({
  windowMs: (Number(process.env.RATE_LIMIT_WINDOW) || 15) * 60 * 1000,
  max: Number(process.env.RATE_LIMIT_MAX) || 100,
  standardHeaders: true, legacyHeaders: false,
  message: { success: false, message: 'Too many requests, please try again later.', code: 'RATE_LIMIT_EXCEEDED' }
});
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, max: Number(process.env.AUTH_RATE_LIMIT_MAX) || 10,
  standardHeaders: true, legacyHeaders: false,
  message: { success: false, message: 'Too many authentication attempts, please try again later.', code: 'AUTH_RATE_LIMIT' }
});

app.use((req, res, next) => {
  req.id = req.get('X-Request-ID') || crypto.randomUUID();
  res.setHeader('X-Request-ID', req.id);
  const startedAt = Date.now();
  res.on('finish', () => logger.info(`${req.method} ${req.originalUrl} ${res.statusCode}`, {
    requestId: req.id, durationMs: Date.now() - startedAt, ip: req.ip
  }));
  next();
});
app.use(express.json({ limit: process.env.JSON_BODY_LIMIT || '2mb' }));
app.use(express.urlencoded({ extended: true, limit: '2mb' }));
app.use('/uploads', express.static(path.join(__dirname, 'uploads'), { dotfiles: 'deny', index: false }));
app.use('/api/', limiter);

app.get('/api/health', (req, res) => res.json({
  success: true, status: 'healthy', timestamp: new Date().toISOString(),
  version: process.env.APP_VERSION || '1.1.0', environment: process.env.NODE_ENV || 'development',
  requestId: req.id
}));
app.get('/api/ready', (req, res) => res.json({ success: true, status: 'ready', requestId: req.id }));

app.use('/api/auth', authLimiter, authRoutes);
app.use('/api/chat', chatRoutes);
app.use('/api/files', fileRoutes);
app.use('/api/search', searchRoutes);
app.use('/api/memory', memoryRoutes);
app.use('/api/admin', adminRoutes);

app.use((req, res) => res.status(404).json({ success: false, message: 'Endpoint not found', path: req.path, code: 'NOT_FOUND', requestId: req.id }));
app.use(errorHandler);

const startServer = async () => {
  initializeFirebase();
  await connectDatabase();
  startCleanupJob();
  const server = app.listen(PORT, () => logger.info(`AI Agent server listening on port ${PORT}`, { environment: process.env.NODE_ENV }));
  const shutdown = signal => {
    logger.info(`${signal} received, shutting down gracefully`);
    server.close(() => process.exit(0));
    setTimeout(() => process.exit(1), 10000).unref();
  };
  process.once('SIGTERM', () => shutdown('SIGTERM'));
  process.once('SIGINT', () => shutdown('SIGINT'));
  return server;
};

if (require.main === module) {
  startServer().catch(error => { logger.error('Failed to start server', error); process.exit(1); });
}

module.exports = { app, startServer };
