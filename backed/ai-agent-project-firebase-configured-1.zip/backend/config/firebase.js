const { initializeApp, getApps, getApp, cert } = require('firebase-admin/app');
const { getAuth } = require('firebase-admin/auth');
const logger = require('../utils/logger');

let app = null;

const required = ['FIREBASE_PROJECT_ID', 'FIREBASE_PRIVATE_KEY', 'FIREBASE_CLIENT_EMAIL'];
const initializeFirebase = () => {
  if (getApps().length > 0) { app = getApp(); return app; }
  const missing = required.filter(key => !process.env[key] || process.env[key].includes('your-') || process.env[key].includes('YOUR_'));
  if (missing.length) {
    throw new Error(`Missing Firebase configuration: ${missing.join(', ')}. Configure backend/.env before starting the server.`);
  }
  try {
    app = initializeApp({
      credential: cert({
        projectId: process.env.FIREBASE_PROJECT_ID,
        privateKey: process.env.FIREBASE_PRIVATE_KEY.replace(/\\n/g, '\n'),
        clientEmail: process.env.FIREBASE_CLIENT_EMAIL
      }),
      databaseURL: process.env.FIREBASE_DATABASE_URL || undefined
    });
    logger.info('Firebase Admin initialized successfully');
    return app;
  } catch (error) {
    logger.error('Firebase initialization failed', error);
    throw error;
  }
};

const getFirebaseApp = () => {
  if (!app) throw new Error('Firebase not initialized. Call initializeFirebase() first.');
  return app;
};
const getFirebaseAuth = () => getAuth(getFirebaseApp());
module.exports = { initializeFirebase, getFirebaseApp, getFirebaseAuth };
