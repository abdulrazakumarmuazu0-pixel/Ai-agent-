const express = require('express');
const { authenticate, authorize, requireSuperAdmin, canManageTarget } = require('../middleware/auth');
const { getDatabase } = require('../config/database');
const User = require('../models/User');
const logger = require('../utils/logger');

const VALID_ROLES = ['user', 'admin', 'superadmin'];

const router = express.Router();
router.use(authenticate);
router.use(authorize('admin', 'superadmin'));

router.get('/stats', async (req, res, next) => {
  try {
    const db = getDatabase();
    const usersSnapshot = await db.collection('users').count().get();
    const conversationsSnapshot = await db.collection('conversations').count().get();
    const messagesSnapshot = await db.collection('messages').count().get();
    const filesSnapshot = await db.collection('files').count().get();

    const recentUsers = await db.collection('users').orderBy('createdAt', 'desc').limit(5).get();
    const recentMessages = await db.collection('messages').orderBy('createdAt', 'desc').limit(10).get();

    res.json({
      success: true,
      data: {
        counts: { users: usersSnapshot.data().count, conversations: conversationsSnapshot.data().count, messages: messagesSnapshot.data().count, files: filesSnapshot.data().count },
        recentUsers: recentUsers.docs.map(d => ({ id: d.id, ...d.data() })),
        recentMessages: recentMessages.docs.map(d => ({ id: d.id, ...d.data() }))
      }
    });
  } catch (error) { next(error); }
});

router.get('/users', async (req, res, next) => {
  try {
    const db = getDatabase();
    const { limit = 50, status, role } = req.query;
    let query = db.collection('users').orderBy('createdAt', 'desc');
    if (status) query = query.where('status', '==', status);
    if (role) query = query.where('role', '==', role);
    if (limit) query = query.limit(parseInt(limit));
    const snapshot = await query.get();
    const users = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
    res.json({ success: true, data: { users, count: users.length } });
  } catch (error) { next(error); }
});

router.put('/users/:id', async (req, res, next) => {
  try {
    const { id } = req.params;
    const { status, role, plan } = req.body;
    const user = await User.findById(id);
    if (!user) return res.status(404).json({ success: false, message: 'User not found', code: 'USER_NOT_FOUND' });

    // Role hierarchy: a plain admin can never touch another admin/superadmin
    // account, and can never assign the 'role' field at all - only a
    // superadmin can promote/demote anyone. This route stays available to
    // both roles for status/plan changes on ordinary users.
    if (!canManageTarget(req, user)) {
      logger.warn(`Admin ${req.user.email} blocked from modifying ${user.role} account ${id}`);
      return res.status(403).json({
        success: false,
        message: 'You cannot modify an admin or superadmin account',
        code: 'FORBIDDEN'
      });
    }

    if (role !== undefined) {
      return res.status(403).json({
        success: false,
        message: 'Role changes must go through PUT /admin/users/:id/role (superadmin only)',
        code: 'USE_ROLE_ENDPOINT'
      });
    }

    const updates = {};
    if (status) updates.status = status;
    if (plan) updates.plan = plan;
    await user.update(updates);

    logger.info(`Admin ${req.user.uid} updated user ${id}: ${JSON.stringify(updates)}`);
    res.json({ success: true, message: 'User updated', data: { user: user.toJSON() } });
  } catch (error) { next(error); }
});

// Dedicated, superadmin-only endpoint for role changes - keeps privilege
// escalation impossible through the general-purpose update route above.
router.put('/users/:id/role', requireSuperAdmin, async (req, res, next) => {
  try {
    const { id } = req.params;
    const { role } = req.body;

    if (!role || !VALID_ROLES.includes(role)) {
      return res.status(400).json({
        success: false,
        message: `Role must be one of: ${VALID_ROLES.join(', ')}`,
        code: 'INVALID_ROLE'
      });
    }

    const user = await User.findById(id);
    if (!user) return res.status(404).json({ success: false, message: 'User not found', code: 'USER_NOT_FOUND' });

    if (id === req.user.uid && role !== 'superadmin') {
      return res.status(400).json({
        success: false,
        message: 'You cannot demote your own account',
        code: 'CANNOT_SELF_DEMOTE'
      });
    }

    // Never allow the last superadmin to be demoted or deleted-in-role,
    // or the system could end up with no one able to manage roles at all.
    if (user.role === 'superadmin' && role !== 'superadmin') {
      const db = getDatabase();
      const superadminCount = await db.collection('users').where('role', '==', 'superadmin').count().get();
      if (superadminCount.data().count <= 1) {
        return res.status(400).json({
          success: false,
          message: 'Cannot demote the last remaining superadmin',
          code: 'LAST_SUPERADMIN'
        });
      }
    }

    const previousRole = user.role;
    await user.update({ role });

    logger.info(`Superadmin ${req.user.email} changed role of ${user.email} from ${previousRole} to ${role}`);
    res.json({ success: true, message: 'Role updated', data: { user: user.toJSON() } });
  } catch (error) { next(error); }
});

// Listing who holds elevated roles is itself sensitive - superadmin only.
router.get('/admins', requireSuperAdmin, async (req, res, next) => {
  try {
    const db = getDatabase();
    const snapshot = await db.collection('users').where('role', 'in', ['admin', 'superadmin']).get();
    const admins = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
    res.json({ success: true, data: { admins, count: admins.length } });
  } catch (error) { next(error); }
});

module.exports = router;